local function setPauseMenuLabels()
    local playerId = GetPlayerServerId(PlayerId())

    Citizen.InvokeNative(
        GetHashKey('ADD_TEXT_ENTRY'),
        'FE_THDR_GTAO',
        ('MYTH DEVELOPMENT | ID : %s'):format(playerId)
    )

    Citizen.InvokeNative(GetHashKey('ADD_TEXT_ENTRY'), 'PM_SCR_MAP', 'Kartta')
    Citizen.InvokeNative(GetHashKey('ADD_TEXT_ENTRY'), 'PM_SCR_GAM', 'Peli')
    Citizen.InvokeNative(GetHashKey('ADD_TEXT_ENTRY'), 'PM_SCR_INF', 'Tiedot')
    Citizen.InvokeNative(GetHashKey('ADD_TEXT_ENTRY'), 'PM_SCR_STA', 'Tilastot')
    Citizen.InvokeNative(GetHashKey('ADD_TEXT_ENTRY'), 'PM_SCR_SET', 'Asetukset')
    Citizen.InvokeNative(GetHashKey('ADD_TEXT_ENTRY'), 'PM_SCR_GAL', 'Galleria')
    Citizen.InvokeNative(GetHashKey('ADD_TEXT_ENTRY'), 'PM_SCR_RPL', 'Editor')
    Citizen.InvokeNative(GetHashKey('ADD_TEXT_ENTRY'), 'PM_PANE_LEAVE', 'Poistu palvelimelta')
    Citizen.InvokeNative(GetHashKey('ADD_TEXT_ENTRY'), 'PM_PANE_QUIT', 'Sulje FiveM')
end

CreateThread(function()
    while true do
        Wait(100)

        setPauseMenuLabels()
    end
end)

CreateThread(function()
    while true do
        Wait(0)

        if IsPauseMenuActive() then
            local playerId = GetPlayerServerId(PlayerId())

            Citizen.InvokeNative(
                GetHashKey('ADD_TEXT_ENTRY'),
                'FE_THDR_GTAO',
                ('MYTH DEVELOPMENT | ID : %s'):format(playerId)
            )
        end
    end
end)