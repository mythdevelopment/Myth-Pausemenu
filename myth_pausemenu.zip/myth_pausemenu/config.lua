Config = {}

Config.Title = 'MYTH DEVELOPMENT'

Config.Map = 'Kartta'
Config.Game = 'Peli'
Config.Info = 'Tiedot'
Config.Stats = 'Tilastot'
Config.Settings = 'Asetukset'
Config.Gallery = 'Galleria'
Config.Editor = 'Editor'

Config.Disconnect = 'Poistu palvelimelta'
Config.Quit = 'Sulje FiveM'

Config.Header = {
    line1 = 'VX DEV',
    line2 = 'ID: %s',
    line3 = 'rx'
}

Config.UseGreenAccent = true

Config.Accent = {
    r = 0,
    g = 255,
    b = 0,
    a = 255
}