fx_version 'cerulean'
game 'gta5'

author 'MYTH DEVELOPMENT'
description 'MYTH DEVELOPMENT Pause Menu'
version '1.0.0'

lua54 'yes'

shared_script 'config.lua'
client_script 'client.lua'